import cv2
import numpy as np
from PIL import Image
import os

print("=" * 40)
print("  Face Recognition Model Trainer")
print("=" * 40)

# Paths
dataset_path = 'dataset'
trainer_path = 'trainer'

os.makedirs(trainer_path, exist_ok=True)

# Create LBPH recognizer
recognizer = cv2.face.LBPHFaceRecognizer_create()

# Load face detector
detector = cv2.CascadeClassifier(
    cv2.data.haarcascades + "haarcascade_frontalface_default.xml"
)


def get_images_and_labels(path):
    face_samples = []
    ids = []

    image_paths = [
        os.path.join(path, f)
        for f in os.listdir(path)
        if f.lower().endswith(('.jpg', '.jpeg', '.png'))
    ]

    if not image_paths:
        print("ERROR: No images found in dataset folder.")
        return face_samples, ids

    print(f"Found {len(image_paths)} images. Processing...")

    for image_path in image_paths:
        try:
            # Convert to grayscale numpy array
            pil_img = Image.open(image_path).convert('L')
            img_numpy = np.array(pil_img, 'uint8')

            # Extract student ID from filename: User.<id>.<count>.jpg
            filename = os.path.basename(image_path)
            parts = filename.split(".")
            if len(parts) < 3:
                print(f"  Skipping (bad filename): {filename}")
                continue

            student_id = int(parts[1])

            faces = detector.detectMultiScale(img_numpy, scaleFactor=1.3, minNeighbors=5)

            for (x, y, w, h) in faces:
                face_samples.append(img_numpy[y:y+h, x:x+w])
                ids.append(student_id)

        except Exception as e:
            print(f"  Error processing {image_path}: {e}")

    return face_samples, ids


print("Training faces. Please wait...")

faces, ids = get_images_and_labels(dataset_path)

if len(faces) == 0:
    print("ERROR: No faces detected in dataset. Cannot train model.")
    input("Press ENTER to close...")
else:
    recognizer.train(faces, np.array(ids))
    model_path = os.path.join(trainer_path, 'trainer.yml')
    recognizer.write(model_path)
    print(f"Model trained successfully with {len(faces)} face samples!")
    print(f"Model saved to: {model_path}")
    input("Press ENTER to close...")
