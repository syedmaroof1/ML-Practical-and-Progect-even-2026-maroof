import cv2
import os
import sys

# Create dataset folder if not exists
os.makedirs("dataset", exist_ok=True)

# Get student ID from command-line argument or prompt
if len(sys.argv) > 1:
    student_id = sys.argv[1]
else:
    student_id = input("Enter Student ID: ")

print(f"Capturing faces for Student ID: {student_id}")
print("Look at the camera. Press ENTER or capture 50 images to stop.")

# Open webcam
cam = cv2.VideoCapture(0, cv2.CAP_DSHOW)

if not cam.isOpened():
    print("ERROR: Cannot access webcam.")
    sys.exit(1)

# Load face detector
face_detector = cv2.CascadeClassifier(
    cv2.data.haarcascades + "haarcascade_frontalface_default.xml"
)

count = 0

while True:
    ret, frame = cam.read()
    if not ret:
        print("Failed to grab frame.")
        break

    gray = cv2.cvtColor(frame, cv2.COLOR_BGR2GRAY)
    faces = face_detector.detectMultiScale(gray, scaleFactor=1.3, minNeighbors=5)

    for (x, y, w, h) in faces:
        count += 1

        # Save face image
        img_path = f"dataset/User.{student_id}.{count}.jpg"
        cv2.imwrite(img_path, gray[y:y+h, x:x+w])

        # Draw rectangle and counter
        cv2.rectangle(frame, (x, y), (x+w, y+h), (255, 0, 0), 2)
        cv2.putText(
            frame,
            f"Captured: {count}/50",
            (x, y - 10),
            cv2.FONT_HERSHEY_SIMPLEX,
            0.8,
            (0, 255, 0),
            2
        )

    cv2.imshow(f"Capturing Faces - Student {student_id} (Press ENTER to stop)", frame)

    key = cv2.waitKey(1)
    if key == 13 or count >= 50:  # ENTER key or 50 images
        break

cam.release()
cv2.destroyAllWindows()

print(f"Done! {count} face images captured for Student ID {student_id}.")
