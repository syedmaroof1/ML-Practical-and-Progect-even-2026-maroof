from flask import Flask, render_template, request, redirect, url_for
import os
import json
import subprocess
import pandas as pd
from datetime import datetime

app = Flask(__name__)

STUDENTS_FILE = "students.json"
ATTENDANCE_FOLDER = "attendance"
DATASET_FOLDER = "dataset"
TRAINER_PATH = "trainer/trainer.yml"


# ─────────────────────────────────────────────
# Helpers
# ─────────────────────────────────────────────

def load_students():
    if os.path.exists(STUDENTS_FILE):
        with open(STUDENTS_FILE, "r") as f:
            return json.load(f)
    return {}


def save_students(data):
    with open(STUDENTS_FILE, "w") as f:
        json.dump(data, f, indent=4)


def get_next_student_id():
    students = load_students()
    if not students:
        return 1
    return max(int(k) for k in students.keys()) + 1


def get_image_counts():
    """Return dict of { student_id_str: count } for dataset images."""
    counts = {}
    if os.path.exists(DATASET_FOLDER):
        for fname in os.listdir(DATASET_FOLDER):
            parts = fname.split(".")
            if len(parts) >= 3:
                sid = parts[1]
                counts[sid] = counts.get(sid, 0) + 1
    return counts


def get_attendance_count():
    if not os.path.exists(ATTENDANCE_FOLDER):
        return 0
    return len([f for f in os.listdir(ATTENDANCE_FOLDER) if f.endswith('.csv')])


def template_context(**kwargs):
    """Build common template variables."""
    ctx = {
        "students": load_students(),
        "model_exists": os.path.exists(TRAINER_PATH),
        "attendance_count": get_attendance_count(),
        "image_counts": get_image_counts(),
        "records": [],
    }
    ctx.update(kwargs)
    return ctx


# ─────────────────────────────────────────────
# HOME
# ─────────────────────────────────────────────
@app.route('/')
def home():
    return render_template('index.html', **template_context())


# ─────────────────────────────────────────────
# REGISTER STUDENT & CAPTURE FACES
# ─────────────────────────────────────────────
@app.route('/register', methods=['POST'])
def register():
    name = request.form.get('name', '').strip()
    if not name:
        return render_template('index.html',
                               **template_context(error="Student name cannot be empty."))

    students = load_students()
    student_id = get_next_student_id()
    students[str(student_id)] = name
    save_students(students)

    # Launch capture script in a new console window
    subprocess.Popen(
        ["python", "capture_faces.py", str(student_id)],
        creationflags=subprocess.CREATE_NEW_CONSOLE
    )

    return render_template('index.html',
                           **template_context(
                               success=f"Capturing faces for '{name}' (ID: {student_id}). "
                                       f"A camera window has opened — press ENTER when done (50 images max)."
                           ))


# ─────────────────────────────────────────────
# TRAIN MODEL
# ─────────────────────────────────────────────
@app.route('/train')
def train():
    if not os.path.exists(DATASET_FOLDER) or len(os.listdir(DATASET_FOLDER)) == 0:
        return render_template('index.html',
                               **template_context(
                                   error="No face images found. Please register students first."
                               ))

    subprocess.Popen(
        ["python", "train_model.py"],
        creationflags=subprocess.CREATE_NEW_CONSOLE
    )

    return render_template('index.html',
                           **template_context(
                               success="Model training started in a new window. "
                                       "Wait for it to finish before taking attendance."
                           ))


# ─────────────────────────────────────────────
# TAKE ATTENDANCE
# ─────────────────────────────────────────────
@app.route('/attendance')
def attendance():
    if not os.path.exists(TRAINER_PATH):
        return render_template('index.html',
                               **template_context(
                                   error="Trained model not found. Please train the model first."
                               ))

    subprocess.Popen(
        ["python", "attendance.py"],
        creationflags=subprocess.CREATE_NEW_CONSOLE
    )

    return render_template('index.html',
                           **template_context(
                               success="Attendance system started. "
                                       "Press ENTER in the camera window to stop and save."
                           ))


# ─────────────────────────────────────────────
# VIEW ATTENDANCE RECORDS
# ─────────────────────────────────────────────
@app.route('/view_attendance')
def view_attendance():
    records = []
    if os.path.exists(ATTENDANCE_FOLDER):
        csv_files = sorted(
            [f for f in os.listdir(ATTENDANCE_FOLDER) if f.endswith('.csv')],
            reverse=True
        )
        for csv_file in csv_files:
            try:
                df = pd.read_csv(os.path.join(ATTENDANCE_FOLDER, csv_file))
                for _, row in df.iterrows():
                    records.append({
                        "name": row.get("Name", ""),
                        "date": row.get("Date", ""),
                        "time": row.get("Time", ""),
                        "file": csv_file
                    })
            except Exception:
                pass

    return render_template('index.html', **template_context(records=records))


# ─────────────────────────────────────────────
# DELETE STUDENT
# ─────────────────────────────────────────────
@app.route('/delete_student/<int:student_id>', methods=['POST'])
def delete_student(student_id):
    students = load_students()
    sid = str(student_id)
    if sid in students:
        del students[sid]
        save_students(students)

        # Remove dataset images for this student
        if os.path.exists(DATASET_FOLDER):
            for f in os.listdir(DATASET_FOLDER):
                if f.startswith(f"User.{student_id}."):
                    os.remove(os.path.join(DATASET_FOLDER, f))

    return redirect(url_for('home'))


# ─────────────────────────────────────────────
# MAIN
# ─────────────────────────────────────────────
if __name__ == '__main__':
    os.makedirs(ATTENDANCE_FOLDER, exist_ok=True)
    os.makedirs(DATASET_FOLDER, exist_ok=True)
    os.makedirs("trainer", exist_ok=True)
    app.run(debug=True)
