import cv2
import numpy as np
import pandas as pd
from datetime import datetime
import os
import json

print("=" * 40)
print("  Face Attendance System")
print("=" * 40)

# ── Paths ──────────────────────────────────────
TRAINER_PATH = 'trainer/trainer.yml'
STUDENTS_FILE = 'students.json'
ATTENDANCE_FOLDER = 'attendance'

os.makedirs(ATTENDANCE_FOLDER, exist_ok=True)

# ── Load trained model ─────────────────────────
if not os.path.exists(TRAINER_PATH):
    print("ERROR: Trained model not found. Please train the model first.")
    input("Press ENTER to close...")
    exit(1)

recognizer = cv2.face.LBPHFaceRecognizer_create()
recognizer.read(TRAINER_PATH)

# ── Load face detector ─────────────────────────
face_cascade = cv2.CascadeClassifier(
    cv2.data.haarcascades + 'haarcascade_frontalface_default.xml'
)

# ── Load student names ─────────────────────────
def load_students():
    if os.path.exists(STUDENTS_FILE):
        with open(STUDENTS_FILE, "r") as f:
            return json.load(f)
    return {}

names = load_students()  # { "1": "Alice", "2": "Bob", ... }

# ── Open webcam ────────────────────────────────
cam = cv2.VideoCapture(0, cv2.CAP_DSHOW)

if not cam.isOpened():
    print("ERROR: Cannot access webcam.")
    input("Press ENTER to close...")
    exit(1)

font = cv2.FONT_HERSHEY_SIMPLEX

# Track attendance to avoid duplicates in one session
attendance_dict = {}   # { name: (date, time) }

print("Camera started. Press ENTER to stop and save attendance.")

while True:
    ret, frame = cam.read()
    if not ret:
        print("Failed to grab frame.")
        break

    gray = cv2.cvtColor(frame, cv2.COLOR_BGR2GRAY)

    faces = face_cascade.detectMultiScale(
        gray,
        scaleFactor=1.2,
        minNeighbors=5,
        minSize=(50, 50)
    )

    for (x, y, w, h) in faces:
        face_roi = gray[y:y+h, x:x+w]
        student_id, confidence = recognizer.predict(face_roi)

        now = datetime.now()
        date_str = now.strftime("%d-%m-%Y")
        time_str = now.strftime("%H:%M:%S")

        if confidence < 85:
            name = names.get(str(student_id), f"ID:{student_id}")
            label = f"{name} ({round(100 - confidence)}%)"
            color = (0, 255, 0)

            # Record attendance (only once per person per session)
            if name not in attendance_dict:
                attendance_dict[name] = (date_str, time_str)
                print(f"  Attendance marked: {name} at {time_str}")

        else:
            label = "Unknown"
            color = (0, 0, 255)

        # Draw bounding box and label
        cv2.rectangle(frame, (x, y), (x+w, y+h), color, 2)
        cv2.rectangle(frame, (x, y-35), (x+w, y), color, cv2.FILLED)
        cv2.putText(frame, label, (x+5, y-10), font, 0.6, (255, 255, 255), 2)

    # Show attendance count on frame
    cv2.putText(
        frame,
        f"Present: {len(attendance_dict)} | Press ENTER to save",
        (10, 30),
        font,
        0.7,
        (255, 255, 0),
        2
    )

    cv2.imshow("Face Attendance System (Press ENTER to stop)", frame)

    if cv2.waitKey(1) == 13:  # ENTER key
        break

cam.release()
cv2.destroyAllWindows()

# ── Save attendance ────────────────────────────
if attendance_dict:
    rows = [
        {"Name": name, "Date": date, "Time": time}
        for name, (date, time) in attendance_dict.items()
    ]
    df = pd.DataFrame(rows, columns=["Name", "Date", "Time"])
    file_name = os.path.join(
        ATTENDANCE_FOLDER,
        f"Attendance_{datetime.now().strftime('%Y%m%d_%H%M%S')}.csv"
    )
    df.to_csv(file_name, index=False)
    print(f"\nAttendance saved to: {file_name}")
    print(df.to_string(index=False))
else:
    print("\nNo attendance recorded.")

input("\nPress ENTER to close...")
